DRIVER :



1) .rpm per Distribuzioni Fedora,Red Hat e Suse
2) .deb per Sebian,Ubuntu e Simpli Mephis
3) ACR38Driver.bundle.zip driver puro da installare manualmente